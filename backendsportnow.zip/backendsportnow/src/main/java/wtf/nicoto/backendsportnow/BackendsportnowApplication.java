package wtf.nicoto.backendsportnow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendsportnowApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendsportnowApplication.class, args);
	}
}
